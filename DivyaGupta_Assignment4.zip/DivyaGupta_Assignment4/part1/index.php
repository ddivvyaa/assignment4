
<?php
//Divya Gupta 8622600
//checking the amount on button clicks
            $money = $remaining = 0;
            $product = '';
            require('machinecode.php');
            if(isset($_POST['one']))
            {
                $money = $_POST['money'] + 100;
            }
            if(isset($_POST['five']))
            {
                $money = $_POST['money'] + 5;
            }
            if(isset($_POST['ten']))
            {
                $money = $_POST['money'] + 10;
            }
            if(isset($_POST['twentyfive']))
            {
                $money = $_POST['money'] +25;
            }
            

            if(isset($_POST['submit']))
            {
//vaildation message
                if(!isset($_POST['snack']))
                    echo "Kinldy choose a product";
                else
                {
                    $money = $_POST['money'];
                    $product = $_POST['snack'];
//checking which product is selected
                    switch ($product) {
                        case "Chocolate":
//if conditions for checking the amount to buy anything
                            if($money < 125)
                                echo "Add enough money to grab the product";
                            else
                            {
                               $chocolate = new Vending('Chocolate', $money, 125);
                               $chocolate->sale();    
                            }
                            break;
                        case "Pop":
                            if($money < 150)
                                echo "Add enough money to grab the product";
                            else
                            {
                               $chocolate = new Vending('Pop', $money, 150);
                               $chocolate->sale();
                            }
                            break;
                        case "Chips":
                            if($money < 175)
                                echo "Add enough money to grab the product";
                            else
                            {
                               $chocolate = new Vending('Chips', $money, 175);
                               $chocolate->sale();
                            }
                            break;
                    }
                    
                    
                    
                }
                
                    
                    
                    
            }
                
             
            
        ?>

<html>

<head>
    <title>part 1</title>
<!--    links for script files-->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style>
/*        making a form*/
    form {
    box-shadow: 7px 3px 19px #000;
    padding: 85px 40px;
}
    </style>
</head>

<body> 
<!--    form for vending machine-->
    <h1>Vending Machine</h1>
    <div class="container">
        <form action='' method='post'>
            your amount (in cents): <input type="text" name="money" id='money' value="<?php echo $money;?>"/>
            <br>
            Product List:<br>
            <input type="radio" name="snack" value="Chocolate" <?php if(isset($product)){ if($product=='Chocolate' ) echo 'checked = "checked"' ; else echo '' ;} ?>>Chocolate Bar $1.25<br>
            <input type="radio" name="snack" value="Pop" <?php if(isset($product)){ if($product=='Pop' ) echo 'checked = "checked"' ; else echo '' ;} ?>> Pop $1.50<br>
            <input type="radio" name="snack" value="Chips" <?php if(isset($product)){ if($product=='Chips' ) echo 'checked = "checked"' ; else echo '' ;} ?>>Chips $1.75<br>
            <br>
<!--buttons for different coins-->
            Coins to enter amount:
            <button name='one' class="btn btn-warning">1$</button>
            <button name='five' class="btn btn-warning">5 	&#162;</button>
            <button name='ten' class="btn btn-warning">10 	&#162;</button>
            <button name='twentyfive' class="btn btn-warning">25 	&#162;</button><br><br>

            <input type="submit" name="submit" class="btn btn-success">

        </form>
    </div>



</body>

</html>
