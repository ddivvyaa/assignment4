<?php
//DivyaGupta 8622600
class Vending
{
   
    var $product = '';
    var $amount = 0;
    var $price = 0;
    var $remainingamount = 0;
//    declarations of variables
    function __construct($product, $amount, $price)
    {
        $this->product = $product;
        $this->amount = $amount;
        $this->price = $price;
    }
//    for getting the change
    function sale()
    {
    $this->remainingamount = $this->amount - $this->price;
    if($this->remainingamount > 0)
        echo "Thank You, and the change is here".$this->remainingamount ." cents!!";
    else
        echo "ThankYou!!";
    }
}

?>