<?php
//DivyaGupta 8622600

    require('mysqli_oop_connect.php');    
       

   //making the query
    $q = "SELECT * from messages";
   
    // running the query
    $r = $mysqli->query($q); 

    // condition to count the rows
    $num = $r->num_rows;
    if ($num > 0) 
     { 
        
    // printing all the records
	while ($row = $r->fetch_object())
    {
		echo '<span>' . $row->username . '</span> || <span>' . $row->message . '</span>
		<br>';
	}

//for freeing up the resources
	$r->free(); 
 	unset($r);

  } 
else 
{ 
    // condition if no records were returned

	echo '<h3>No data</h3>';

}

// close the database connection
$mysqli->close();
unset($mysqli);


?>
