<?php
//DivyaGupta862200
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
//taking the values from POST and saving them    
$username=$_REQUEST['username'];
$message=$_REQUEST['message'];
   
if(empty ($username) or empty($message) )
        {
		 echo "One of the input not entered..!";
		}
    else
    {
//        creating SQL query and making connection
         require('mysqli_oop_connect.php');
        
        $q = "INSERT INTO messages VALUES(? , ?)";
        
        $st=$mysqli->prepare($q);
        
        $st->bind_param('ss',$username,$message);
        
        $username=strip_tags($_POST['username']);
        $messsage=strip_tags($_POST['message']);
        
        $st->execute();
        
        if($st->affected_rows == 1)
//            showing messages with echo
        {
            echo "Your Message has been posted.";
        }
        else
        {
            echo '<span>' . $st->error . '</span>';
        }
        
        $st->close();
        unset($st);
        
        $mysqli->close();
	    unset($mysqli);
        
    }
}
?>